from .auto_styler import AutoStyler

def classFactory(iface):
    return AutoStyler(iface)


